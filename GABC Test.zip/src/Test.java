
public class Test {

	public String testString;
	
	Test(String t)
	{
		testString = t;
	}
	
}
